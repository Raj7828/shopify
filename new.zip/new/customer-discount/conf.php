<?php
       
	define('SHOPIFY_APP_API_KEY', '9e53013d7a623388ca80662e3e29314b');
	define('SHOPIFY_APP_SHARED_SECRET', '470d49f89f7cae74e962f5206ee9dfb9');
	define('SHOPIFY_SITE_URL', 'https://shopify.galaxyweblinks.in/customer-discount/'); // App path
	define('REDIRECT_URL', 'https://shopify.galaxyweblinks.in/customer-discount/oauth.php'); // Oauth file
	$conn = mysqli_connect('192.168.7.245','shopify','No073#$asdf','shopify');
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}