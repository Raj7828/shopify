<?php
	session_start();
	require __DIR__.'/vendor/autoload.php';
	use phpish\shopify;
	require __DIR__.'/conf.php';

	$shopify = shopify\client($_SESSION['shop'], SHOPIFY_APP_API_KEY, $_SESSION['oauth_token']);
	$products = $shopify('GET /admin/products.json', array('published_status'=>'published'));
	$shop_name = $_SESSION['shop'];


  /**
  * Create the table if not exist
  **/
	$apply_coupons_customer_table =	"CREATE TABLE IF NOT EXISTS apply_coupons_customer ( 
		id bigint NOT NULL AUTO_INCREMENT,
		customer_id bigint NOT NULL,
		customer_name VARCHAR(100) NOT NULL,
		customer_email VARCHAR(200) NOT NULL,
		discount_id bigint NOT NULL,
		disocount_title VARCHAR(100) NOT NULL,
		discount_percent bigint NOT NULL,
		shop VARCHAR(300) NOT NULL,
		PRIMARY KEY(id),
		UNIQUE (customer_id),
		UNIQUE (discount_id)
	)";
	$apply_coupons_customer_table_status = mysqli_query($conn,$apply_coupons_customer_table);
		if(!$apply_coupons_customer_table_status){
		echo "Something went wrong,table not created - " . mysqli_error($conn);	
		die();
	}

	 /**
  * Add the webhook for order
  **/
  try{
    $add_web_hook = $shopify('POST /admin/webhooks.json', array() ,array('webhook' => 
    array(
    'topic'   => 'customers/create',
    'address' =>  'https://shopify.galaxyweblinks.in/customer-discount/customer-webhook.php?shop='.$shop_name.'&oauth_token='.$_SESSION['oauth_token'],
    'format'  => 'json' 
    )));
    print_r($add_web_hook);
    send_referral_mail('rajkumar.vishwakarma@galaxyweblinks.in','customer webhook on admin dashboard',"admin dashboard -".json_encode($add_web_hook));
  }
  catch(Exception $e) {
     //echo 'webhook not working';
  }

// $get_price_rules = $shopify('GET /admin/price_rules.json');
// 	foreach ($get_price_rules as $value) {
// 		$price_rule_title = $value['title'];
// 		$price_rule_id = $value['id'];
// 		if($price_rule_title =="FRSTPRCASE")
// 		{
// 			try {
// 				// $add_discount = $shopify("PUT /admin/price_rules/".$price_rule_id.".json",array(),array( 
// 				// 	'price_rule' => array(
// 				// 		"title"=> "FRSTPRCASE",
// 				// 		"target_type"=> "line_item",
// 				// 		"target_selection"=> "all",
// 				// 		"allocation_method"=> "across",
// 				// 		"value_type"=> "percentage",
// 				// 		"value"=> "-10",
// 				// 		"once_per_customer"=> true,
// 				// 		"usage_limit"=> "1",
// 				// 		"customer_selection"=> "prerequisite",
// 				// 		"prerequisite_customer_ids"=> array(731387658282),
// 				// 		"starts_at"=> "2018-06-14 4:35am",
// 				// 		"ends_at"=> null
// 				// 	)
// 				// ));	
// 				// $dis_id = $add_discount['id'];
// 				// $update_discount = $shopify("POST /admin/price_rules/".$dis_id."/discount_codes.json",array(),array(
// 				// 	  "discount_code"=> array(
// 				// 	  	  "code"=> "FRSTPRCASE"
// 				// 		)
// 				// ));
// 			} catch (Exception $e) {
// 				echo "Error occour in code";
// 				echo "<pre>";
// 				print_r($e);
// 				echo "</pre>";
// 			}
// 		}
		
// 	}

?>
<h3 style="text-align: center;padding-top: 20px;color: rgb(0,104,0);text-transform: capitalize;font-size: 26px;margin-bottom: 0;">Welcome to the  Apply Coupons shopify app</h3>
<h3 style="text-align: center;color: rgb(0,172,0);text-transform: capitalize;">Now, Every new registered user will get 10% discount on first order</h3>

