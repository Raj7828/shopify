<?php
require __DIR__.'/vendor/autoload.php';
use phpish\shopify;
require __DIR__.'/conf.php';
require __DIR__.'/smtp.php';
$shopify = shopify\client($_REQUEST['shop'], SHOPIFY_APP_API_KEY, $_REQUEST['oauth_token']);
$shop_name = $_REQUEST['shop'];
$data = json_encode($_SERVER);
$get_data = file_get_contents('php://input');
$new_customer_details = json_decode($get_data,true);	

$discount_title = "FIRST".substr($new_customer_details['id'], -6);
$cus_id = $new_customer_details['id'];
$cus_email = $new_customer_details['email'];
$cus_name = $new_customer_details['first_name']." ".$new_customer_details['last_name'];

try 
{
	$add_discount = $shopify("POST /admin/price_rules.json",array(),array( 
		'price_rule' => array(
			"title"=> $discount_title,
			"target_type"=> "line_item",
			"target_selection"=> "all",
			"allocation_method"=> "across",
			"value_type"=> "percentage",
			"value"=> "-10",
			"once_per_customer"=> true,
			"usage_limit"=> "1",
			"customer_selection"=> "prerequisite",
			"prerequisite_customer_ids"=> array($cus_id),
			"starts_at"=> "2018-06-14 4:35am",
			"ends_at"=> null
		)
	));	
	$dis_id = $add_discount['id'];
	$update_discount = $shopify("POST /admin/price_rules/".$dis_id."/discount_codes.json",array(),array(
		  "discount_code"=> array(
		  	  "code"=> $discount_title
			)
	));
	if($dis_id !=''){
		$query = "INSERT INTO `apply_coupons_customer` (`id`, `customer_id`, `customer_name`, `customer_email`, `discount_id`, `disocount_title`, `discount_percent`, `shop`) VALUES (NULL, '$cus_id', '$cus_name', '$cus_email', '$dis_id', '$discount_title',10,'$shop_name')";
		$query_result_status =  mysqli_query($conn,$query);
		if($query_result_status){
			$message = "Congratulations, you got 10% discount at ".$shop_name;
			$message_body = '';
			$message_body .= '<div>Hello '.$cus_name.'</div>';
			$message_body .= '<p>You got 10% discount on your first offer</p>';
			$message_body .= '<p>  <a href="https://'.$shop_name.'/collections/all">Click here</a> to shop</p>';
			$message_body .= '<p>Discount code: '.$discount_title.'</p>';

			$message_body .= '<p>Thanks</p>';
			send_referral_mail($cus_email,$message,$message_body);
		}
	}
} catch (Exception $e) {
	//echo "Error occour while creating discount code";
}




