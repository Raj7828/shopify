<?php
       
	define('SHOPIFY_APP_API_KEY', '81e8d47f87b64e759bfa074b5c3c0d0c');
	define('SHOPIFY_APP_SHARED_SECRET', 'ae620d7e2b67a989039925c6ac4e3491');
	define('SHOPIFY_SITE_URL', 'https://shopify.galaxyweblinks.in/order-export/'); // App path
	define('REDIRECT_URL', 'https://shopify.galaxyweblinks.in/order-export/oauth.php'); // Oauth file
	$conn = mysqli_connect('192.168.7.245','shopify','No073#$asdf','shopify');
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}