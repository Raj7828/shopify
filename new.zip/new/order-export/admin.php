<?php
session_start();
require __DIR__.'/vendor/autoload.php';
use phpish\shopify;
require __DIR__.'/conf.php';
require __DIR__.'/smtp.php';

$shopify = shopify\client($_SESSION['shop'], SHOPIFY_APP_API_KEY, $_SESSION['oauth_token']);
$shop_name = $_SESSION['shop'];

try{
	$admin_details = $shopify('GET /admin/shop.json');
	$shop_owner_email = $admin_details['email'];
}
catch(Exception $e) { 
	$shop_owner_email = '';
}


/**
* Create the order export table
**/
$order_export_table =	"CREATE TABLE IF NOT EXISTS order_export_status ( 
	id bigint NOT NULL AUTO_INCREMENT,
	order_id bigint NOT NULL,
	status bigint NOT NULL,
	PRIMARY KEY(id),
	UNIQUE (order_id)
)";
$table_status = mysqli_query($conn,$order_export_table);
if(!$table_status){
	echo "Something went wrong,table not created - " . mysqli_error($conn);	
	die();
}
/**
* Get the order export details 
**/
if(isset($_POST['export_order_data']))
{	
	$file_create_status = file_put_contents("test.xml",$file_content);
	$selected_orders_id = $_POST['selected_order_list'];
	$count_order_id = count($selected_orders_id);
	$order_ids = array();
	if($count_order_id > 0)
	{
		$order_file_name = "export/order_".time().".xml";
		$fh = fopen($order_file_name, 'w') or die("can't open file"); 
		$file_content = '<?xml version="1.0" encoding="utf-8"?>'.PHP_EOL;
		foreach ($selected_orders_id as  $value) {
		$get_order_data = $shopify("GET /admin/orders/".$value.".json");
		$order_ids[] = $get_order_data["id"];
		$orders_line_items = $get_order_data['line_items'];
		$file_content .='<orderdetails>'.PHP_EOL;
	    $file_content .= '<order_id>'.$get_order_data["id"].'</order_id>';
	    $file_content .= '<Email>'.$get_order_data["email"].'</Email>';
	    $file_content .= '<created_at>'.$get_order_data["created_at"].'</created_at>';
	    $file_content .= '<total_price>'.$get_order_data["total_price"].'</total_price>';
	    $file_content .= '<subtotal_price>'.$get_order_data["subtotal_price"].'</subtotal_price>';
	    $file_content .= '<financial_status>'.$get_order_data["financial_status"].'</financial_status>';
	    $file_content .= '<currency>'.$get_order_data["currency"].'</currency>';
	    $file_content .= '<order_number>'.$get_order_data["order_number"].'</order_number>';
	    $file_content .= '<payment_gateway>'.$get_order_data["gateway"].'</payment_gateway>'.PHP_EOL;
		foreach ($orders_line_items as  $value) {
		$file_content .= '<line_items>'.PHP_EOL;
		$file_content .= '<title>'.$value["title"].'</title>';
		$file_content .= '<quantity>'.$value["quantity"].'</quantity>';
		$file_content .= '<price>'.$value["price"].'</price>';
		$file_content .= '<variant_title>'.$value["variant_title"].'</variant_title>';
		$file_content .= '<product_id>'.$value["product_id"].'</product_id>';
		$file_content .= '<name>'.$value["name"].'</name>';
		$file_content .= '</line_items>'.PHP_EOL;
		}
		$file_content .= '<billing_address>';
		$file_content .= '<name>'.$get_order_data["billing_address"]["name"].'name</name>';
		$file_content .= '<address1>'.$get_order_data["billing_address"]["address1"].'</address1>';
		$file_content .= '<phone>'.$get_order_data["billing_address"]["phone"].'</phone>';
		$file_content .= '<city>'.$get_order_data["billing_address"]["city"].'</city>';
		$file_content .= '<zip>'.$get_order_data["billing_address"]["zip"].'</zip>';
		$file_content .= '<province>'.$get_order_data["billing_address"]["province"].'</province>';
		$file_content .= '<country>'.$get_order_data["billing_address"]["country"].'</country>';
		$file_content .= '<country_code>'.$get_order_data["billing_address"]["country_code"].'</country_code>';
		$file_content .= '<province_code>'.$get_order_data["billing_address"]["province_code"].'</province_code>';
		$file_content .= '</billing_address>'.PHP_EOL;
		$file_content .= '<shipping_address>';
		$file_content .= '<name>'.$get_order_data["shipping_address"]["name"].'name</name>';
		$file_content .= '<address1>'.$get_order_data["shipping_address"]["address1"].'</address1>';
		$file_content .= '<phone>'.$get_order_data["shipping_address"]["phone"].'</phone>';
		$file_content .= '<city>'.$get_order_data["shipping_address"]["city"].'</city>';
		$file_content .= '<zip>'.$get_order_data["shipping_address"]["zip"].'</zip>';
		$file_content .= '<province>'.$get_order_data["shipping_address"]["province"].'</province>';
		$file_content .= '<country>'.$get_order_data["shipping_address"]["country"].'</country>';
		$file_content .= '<country_code>'.$get_order_data["shipping_address"]["country_code"].'</country_code>';
		$file_content .= '<province_code>'.$get_order_data["shipping_address"]["province_code"].'</province_code>';
		$file_content .= '</shipping_address>';
		$file_content .= '</orderdetails>'.PHP_EOL;
		}
		fwrite($fh, $file_content);
		fclose($fh);
		if($order_ids)
		{
			foreach ($order_ids as $value) 
			{
				$check_id = "SELECT * FROM `order_export_status` WHERE `order_id` = $value AND `status` = 1";
				$order_id_result =  mysqli_query($conn,$check_id);
				$order_rows_count = mysqli_num_rows($order_id_result);
				if($order_rows_count == 0)
				{
					$insert_order = "INSERT INTO `order_export_status` (`id`, `order_id`, `status`) VALUES (NULL, '$value',1)";
					$insert_order_status =  mysqli_query($conn,$insert_order);
				}
			}
			$subject = "Order export from https://".$shop_name." Shop";
			$message = "<p>Hi,</p>";
			$message .= "<p>Please find the attachment of order export file</p>";
			$file_path = __DIR__."/".$order_file_name;
			$mail_status = send_order_export_mail($shop_owner_email,$subject,$message,$file_path);	
			if($mail_status =='1'){
				echo '<h2 id="success_msg">Order Exported successfully,Please check your email to view the order details.</h2>';
			}
		}
	}else{
		echo "<p class='selection_errors'>Error, You have not selected any order for export !!!</p>";	
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	 <link rel="stylesheet" type="text/css" href="<?php echo SHOPIFY_SITE_URL."assets/css/jquery.dataTables.min.css"; ?>">
	 <link rel="stylesheet" type="text/css" href="<?php echo SHOPIFY_SITE_URL."assets/css/admin.css"; ?>">
	 <script type="text/javascript" src="<?php echo SHOPIFY_SITE_URL."assets/js/order-jquery.js"; ?>"></script>
	 <script type="text/javascript" src="<?php echo SHOPIFY_SITE_URL."assets/js/jquery.dataTables.min.js"; ?>"></script>
</head>
<body>
	<div id="shop_order_details_wrapper">
		<p class="top_heading">Please select the below orders to export as a .XML file</p>
		<form id="shop_order_details_form" method="post" action="">
			<table id="shop_order_details_table_wrapper" width="100%">
				<thead>
					<tr>
						<th class="header_check_box_section"><input type="checkbox" name="select_all_orders" id="export_all_orders"></th>
						<th>Id</th>
						<th>Date</th>
						<th>Customer</th>
						<th>Payment status</th>
						<th>Total</th>
					</tr>
				</thead>
				<tbody>
					<?php
					$count_orders = $shopify('GET /admin/orders/count.json'); 
					$shop_orders = $shopify('GET /admin/orders.json');
					//echo "Total orders -".$count_orders;
					foreach ($shop_orders as  $value) 
					{ 
						$id = $value['id'];
						$check_id = "SELECT * FROM `order_export_status` WHERE `order_id` = $id  AND `status` = 1";
						$response =  mysqli_query($conn,$check_id);
						$rows_count = mysqli_num_rows($response);
					?>
						<tr class="<?php if($rows_count > 0){ echo 'exported_orders_row'; } ?>">
							<td>
								<?php
								if($rows_count > 0)
								{
									echo "<span class='exported_orders'>Exported</span>";
								}
								else
								{
								?>
									<input type="checkbox" name="selected_order_list[]" value="<?php echo $value['id']; ?>">
								<?php	
								}
								?>
							</td>
							<td><?php echo $value['name']; ?></td>
							<td><?php echo $value['created_at'];  ?></td>
							<td><?php echo $value['customer']['first_name']." ".$value['customer']['last_name']; ?></td>
							<td><?php echo $value['financial_status']; ?></td>
							<td><?php echo $value['total_price']; ?></td>
						</tr>	
					<?php
					}
					?>
			    </tbody>
			</table>
			<p id="wait_message">Please wait while we processing your request !!!</p>
			<p id="submit_button"><input type="submit" id="export_selected_orders" name="export_order_data" value="Export Orders"></p>
		</div>
	</div>
	 <script type="text/javascript">
        jQuery(document).ready(function(){
            jQuery('#shop_order_details_table_wrapper').DataTable({
            	aLengthMenu: [
			        [25, 50, 100, 200, -1],
			        [25, 50, 100, 200, "All"]
			    ],
			    aoColumnDefs: [
				  {
				     bSortable: false,
				     aTargets: [0]
				  }
				]
            });
            jQuery("#export_all_orders").click(function () {
			     jQuery('input:checkbox').not(this).prop('checked', this.checked);
			});
			jQuery("#shop_order_details_form").submit(function(){
			    jQuery("#wait_message").css('display','block');
			    jQuery("#export_selected_orders").css('display','none');
			});
		 });
    </script>
</body>
</html>
