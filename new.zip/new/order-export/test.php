<?php
require __DIR__.'/smtp.php';
$subject = "Order export data";
$message = "Hi,";
$message .= "Please find the attachment of order export file";
$file_path = __DIR__."/export/sample.xml";
echo "File path -".$file_path;
//$mail_status = send_order_export_mail('rajkumar.vishwakarma@galaxyweblinks.in',$subject,$message,$file_path);	
echo "Mail status -".$mail_status;