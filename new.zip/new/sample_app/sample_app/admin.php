<?php
	session_start();
	require __DIR__.'/vendor/autoload.php';
	use phpish\shopify;
	require __DIR__.'/conf.php';

	$shopify = shopify\client($_SESSION['shop'], SHOPIFY_APP_API_KEY, $_SESSION['oauth_token']);
	$products = $shopify('GET /admin/products.json', array('published_status'=>'published'));
	$shop_name = $_SESSION['shop'];
  /**
  * Get the 
  **/
	$theme_details = $shopify('GET /admin/themes.json',array('role'=>'main'));
	$theme_id = $theme_details[0]['id']; //activated theme id
?>

<h3>Welcome to the shopify app</h3>


