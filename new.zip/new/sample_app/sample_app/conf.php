<?php
       
	define('SHOPIFY_APP_API_KEY', '');
	define('SHOPIFY_APP_SHARED_SECRET', '');
	define('SHOPIFY_SITE_URL', ''); // App path
	define('REDIRECT_URL', ''); // Oauth file
	$conn = mysqli_connect('','','','');
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}